# PersonalWebsite
Visit <a href="http://milind-shah.com/">milind-shah.com</a>  
*This site is best viewed on computers/laptops/tablets. The mobile experience is currently being worked on.

