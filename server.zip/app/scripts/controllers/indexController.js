angular.module('personalWebsite')
.controller('IndexCtrl', function(){
	var self = this;
});
