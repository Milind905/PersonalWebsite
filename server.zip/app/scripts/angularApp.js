var app = angular.module('personalWebsite', ['ui.router']);
